<?php

class actionInplayerThemePrefs extends cmsAction {

    private $data_field_blocks = array('datawrap', 'dataimage', 'datatext', 'databg');

	public function run(){

		$template = cmsTemplate::getInstance();

		$theme_name = $this->request->get('theme');

		$layouts = $this->getThemeLayouts($theme_name);

        foreach($layouts as $layout){

            $data_sources_prefs = $this->parseDataSourcesForPrefs($layout['data_sources']);
            $blocks_prefs = $this->parseBlocksForPrefs($layout['blocks'], $data_sources_prefs);

            $prefs[$layout['name']] = array(
                'data_sources' => $data_sources_prefs,
                'blocks' => $blocks_prefs
            );

            if (!empty($layout['prefs'])){

                $block_prefs = $prefs[$layout['name']]['blocks'];
                $ds_prefs = $prefs[$layout['name']]['data_sources'];

                if (!empty($layout['prefs']['blocks'])){
                    foreach($layout['prefs']['blocks'] as $id => $block){
                        if (isset($block_prefs[$id])){
                            $block_prefs[$id] = array_merge($block_prefs[$id], $block);
                        }
                    }
                }

                if (!empty($layout['prefs']['datasources'])){
                    foreach($layout['prefs']['datasources'] as $id => $ds){

                        $ds_prefs[$id]['ctypeId'] = $ds['ctypeId'];

                        foreach($ds['blocks'] as $block_id => $block){
                            if (isset($ds_prefs[$id]['blocks'][$block_id])){

                                $ds_prefs[$id]['blocks'][$block_id] = array_merge($ds_prefs[$id]['blocks'][$block_id], $block);

								if (!empty($block['bgImageField'])){
									$ds_prefs[$id]['blocks'][$block_id]['fieldName'] = $block['bgImageField'];
								}

                            }
                        }

                    }
                }

                $prefs[$layout['name']] = array(
                    'data_sources' => $ds_prefs,
                    'blocks' => $block_prefs
                );

            }

        }

        $menus = array(''=>'') + array_collection_to_list(cmsCore::getModel('menu')->getMenus(), 'id', 'title');
        $ctypes = array(''=>'') + array_collection_to_list(cmsCore::getModel('content')->getContentTypes(), 'id', 'title');

        $field_types = cmsForm::getAvailableFormFields(false, 'content');

		$template->render('theme.prefs', array(
            'prefs' => $prefs,
            'layouts' => $layouts,
            'menus' => $menus,
            'ctypes' => $ctypes,
            'field_types' => $field_types
        ));

	}

    private function parseBlocksForPrefs($blocks, &$data_sources_prefs, $dataSourceId = false, $prefs = array()){

        if (empty($blocks)) { return $prefs; }

        foreach($blocks as $block){

            if ($block['class'] == 'menu'){
                $prefs[$block['id']] = array(
                    'type' => 'menu',
                    'name' => $block['options']['blockName'],
                    'menu' => $block['options']['menu']
                );
            }

            if ($block['class'] == 'heading'){
                $prefs[$block['id']] = array(
                    'type' => 'heading',
                    'name' => $block['options']['blockName'],
                    'text' => $block['options']['text']
                );
            }

            if ($block['class'] == 'text'){
                $prefs[$block['id']] = array(
                    'type' => 'text',
                    'name' => $block['options']['blockName'],
                    'text' => $block['options']['text']
                );
            }

            if ($block['class'] == 'image'){
                $prefs[$block['id']] = array(
                    'type' => 'image',
                    'name' => $block['options']['blockName'],
                    'src' => $block['options']['src']
                );
            }

            if ($block['class'] == 'datablock'){
                $dataSourceId = $block['options']['dataSourceId'];
				$data_sources_prefs[$dataSourceId]['blocks'][$block['id']] = array(
					'title' => $block['options']['blockName'] . ' (' . 'Фон' . ')',
					'fieldType' => 'image',
                    'fieldName' => $block['options']['bgImageField'],
					'saveToField' => 'bgImageField'
				);
            }

            if (in_array($block['class'], $this->data_field_blocks) && $dataSourceId){

                $field_name = $block['options']['fieldName'];
                $field_type = isset($block['options']['fieldType']) ? $block['options']['fieldType'] : false;

                if ($block['class'] == 'databg' || $block['class'] == 'dataimage'){
                    $field_type = 'image';
                }

                $data_sources_prefs[$dataSourceId]['blocks'][$block['id']] = array(
                    'title' => $block['options']['blockName'],
                    'fieldType' => $field_type,
                    'fieldName' => $field_name,
					'saveToField' => 'fieldName'
                );

            }

            if (!empty($block['childs'])){
                $prefs = $this->parseBlocksForPrefs($block['childs'], $data_sources_prefs, $dataSourceId, $prefs);
            }

        }

        return $prefs;

    }

    private function parseDataSourcesForPrefs($data_sources, $prefs = array()){

        if (empty($data_sources)) { return $prefs; }

        foreach($data_sources as $source){

            if ($source['type'] == 'content'){
                $prefs[$source['id']] = array(
                    'type' => 'content_types',
                    'name' => $source['options']['title'],
                    'ctypeId' => $source['options']['ctypeId'],
                    'blocks' => array()
                );
            }

        }

        return $prefs;

    }

}
