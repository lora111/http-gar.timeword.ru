<?php

class actionInplayerThemeFields extends cmsAction {

	private $date_segments = array(
		LANG_MONTH => array('month', '%B'),
		LANG_DAY1 => array('day', '%d'),
		LANG_DAY1 .' + '. LANG_MONTH => array('daymonth', '%d %B'),
		LANG_MONTH .' + '. LANG_DAY1 => array('monthday', '%B %d'),
		LANG_YEAR => array('year', '%Y'),
		LANG_HOURS => array('hour', '%H'),
		LANG_MINUTES => array('min', '%M'),
		LANG_BACK => array('back', 'back'),
	);

	public function run(){

		$template = cmsTemplate::getInstance();

		$ctype_id = $this->request->get('ctype_id');

        $content_model = cmsCore::getModel('content');

        $ctype = $content_model->getContentType($ctype_id);
		$ctype_fields = $content_model->getContentFields($ctype['name']);
        $fields = array();

        foreach($ctype_fields as $field){

            if ($field['type'] == 'image'){

                if (!empty($field['options']['sizes'])){

                    foreach($field['options']['sizes'] as $size){
                        $fields[$field['name'] . '.' . $size] = array(
                            'title' => $field['title'] . ' (' . $size . ')',
                            'type' => $field['type']
                        );
                    }

                    continue;

                }
            }

            if ($field['type'] == 'date'){

				foreach($this->date_segments as $title=>$schema){
					$fields[$field['name'] . '.' . $schema[0]] = array(
						'title' => $field['title'] . ' (' . $title . ')',
						'type' => $field['type']
					);
				}

				continue;

            }

            $fields[$field['name']] = array(
                'title' => $field['title'],
                'type' => $field['type']
            );

        }

		$template->renderJSON($fields);

	}

}
