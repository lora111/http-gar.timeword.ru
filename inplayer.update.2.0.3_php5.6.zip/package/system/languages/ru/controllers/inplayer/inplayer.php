<?php

	define('LANG_INPLAYER_UPDATE_THEMES_SUCCESS', 'Список тем успешно обновлен');
	define('LANG_INPLAYER_UPDATE_THEMES_NEW', 'Найдены новые темы (%d)');
	define('LANG_INPLAYER_UPDATE_THEMES_NO_NEW', 'Новые темы не найдены');
	define('LANG_INPLAYER_UPDATE_THEMES_ERROR', 'Нет установленных тем');
	define('LANG_INPLAYER_UPDATE_THEME_TOO_NEW', 'Тема <strong>&laquo;%s&raquo;</strong> требует более новую версию InPlayer для установки');

	define('LANG_INPLAYER_WIDGETS_SCHEME_SELECT', 'Выберите макет страницы');
    define('LANG_INPLAYER_WIDGETS_SCHEME_NONE', 'Не найдена схема позиций виджетов для макета <strong>%s</strong>');

	define('LANG_INPLAYER_PREF_DS_CONTENT', 'Источник данных');
	define('LANG_INPLAYER_PREF_GRP_MENU', 'Меню');
	define('LANG_INPLAYER_PREF_GRP_HEADING', 'Заголовки');
	define('LANG_INPLAYER_PREF_GRP_TEXT', 'Тексты');
	define('LANG_INPLAYER_PREF_GRP_IMAGE', 'Изображения');

