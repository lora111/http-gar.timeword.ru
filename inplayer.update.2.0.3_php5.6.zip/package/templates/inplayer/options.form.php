<?php

class formInplayerTemplateOptions extends cmsForm {

    public function init() {

		cmsTemplate::getInstance()->addJS('templates/inplayer/js/theme-prefs.js');

		$prefs_load_url = href_to('inplayer', 'theme_prefs');
        $fields_load_url = href_to('inplayer', 'theme_fields');

        return array(

            array(
                'type' => 'fieldset',
                'title' => LANG_INPLAYER_CURRENT_THEME,
                'childs' => array(

					new fieldList('theme', array(
						'hint' => '<div style="margin-top:4px"><a href="'.href_to('inplayer', 'update').'">'.LANG_INPLAYER_UPDATE_THEMES.'</a></div>',
						'generator' => function(){
							$inplayer = cmsCore::getController('inplayer');
							$theme_list = $inplayer->getThemeList();
							if (!$theme_list) { return array(); }
							foreach($theme_list as $theme_name => $theme){
								$theme_list[$theme_name] = "{$theme['title']} ({$theme['version']} - {$theme['author']})";
							}
							return $theme_list;
						}
					))

				)
            ),

			array(
                'type' => 'html',
                'content' => '<div id="theme-options-block" data-prefs-url="'.$prefs_load_url.'" data-fields-url="'.$fields_load_url.'"></div>'
            ),

        );

    }

    public function validate($controller, $data, $is_check_csrf = true){

        $errors = parent::validate($controller, $data, $is_check_csrf);

        if (!$errors){
            $this->saveThemePrefs($controller->request->getData());
        }

        return $errors;

    }

    private function saveThemePrefs($data){

        $prefs = empty($data['prefs']) ? array() : $data['prefs'];

        $inplayer = cmsCore::getController('inplayer');

        $inplayer->saveThemePrefs($data['theme'], $prefs);

    }

}
