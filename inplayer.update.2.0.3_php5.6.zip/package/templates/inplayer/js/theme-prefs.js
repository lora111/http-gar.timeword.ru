$(document).ready(function () {

	var $themeSelect = $('select#theme');
	var $optionsBlock = $('#theme-options-block');

	var prefsUrl = $optionsBlock.data('prefs-url');
    var fieldsUrl = $optionsBlock.data('fields-url');

	$themeSelect.on('change', function(){
		var themeId = $(this).val();
		selectTheme(themeId);
	}).change();

	function selectTheme(themeId){

		$optionsBlock.addClass('loading').empty();

		$.post(prefsUrl, {theme: themeId}, function(html){
			$optionsBlock.removeClass('loading');
			$optionsBlock.html(html);
            initTabs('#layouts-options');
            bindDataSourceCtypeLists();
		}, 'html');

	}

    function bindDataSourceCtypeLists(){

        $('select.ds-ctype-list').each(function(){

            var $ctypeList = $(this);
            var dataSourceId = $ctypeList.data('source-id');

            $ctypeList.change(function(){

                var ctypeId = $(this).val();
                var $fieldLists = $('select.ds-' + dataSourceId);

                $fieldLists.empty().prop('disabled', true);
				$fieldLists.after('<div class="loading" style="display:inline; width:16px; height:16px"></div>');

                if (!ctypeId) { return; }

                $.post(fieldsUrl, {ctype_id: ctypeId}, function(fields){

                    $fieldLists.each(function(){

                        var $fieldList = $(this);
                        var value = $fieldList.data('value');

                        fillFieldList($fieldList, fields);
                        $fieldList.val(value);

                    });

                    $fieldLists.prop('disabled', false).next('.loading').remove();

                }, 'json');

            }).change();

        });

    }

    function fillFieldList($list, fields){

        var type = $list.data('type');

        $.each(fields, function(name, field){
            if (type && field.type != type) { return; }
            if (type != 'image' && field.type == 'image') { return; }
            var $option = $('<option></option>').attr('value', name).text(field.title);
            $option.appendTo($list);
        });

    }

});