<?php

	$grouped_blocks = array();

	if ($prefs){

		foreach($prefs as $layout_id => $opts){

			$grouped_blocks[$layout_id] = array(
				'menu' => array(),
				'heading' => array(),
				'text' => array(),
				'image' => array()
			);

			foreach($opts['blocks'] as $id => $block){
				$grouped_blocks[$layout_id][$block['type']][$id] = $block;
			}

		}

	}

?>

<style>
    #layouts-options { padding: 20px 15px 10px 15px; }
    #layouts-options fieldset {
        margin: 15px;
        border: solid 1px #ECECEC;
    }
    #layouts-options fieldset legend { font-weight: normal; }
    #layouts-options .hint { margin-top:3px; }
</style>
<fieldset id="layouts-options">

    <legend>Настройки макетов</legend>

    <div class="tabs-menu form-tabs">

        <ul class="tabbed">
            <?php foreach($prefs as $layout_id => $opts){ ?>
                <li>
                    <a href="#tab-<?php echo $layout_id; ?>"><?php echo $layouts[$layout_id]['title']; ?></a>
                </li>
            <?php } ?>
        </ul>

        <?php foreach($prefs as $layout_id => $opts){ ?>
            <div id="tab-<?php echo $layout_id; ?>" class="tab">

				<?php foreach ($grouped_blocks[$layout_id] as $section=>$blocks) { ?>

					<fieldset>

						<?php $fs_title = constant('LANG_INPLAYER_PREF_GRP_' . mb_strtoupper($section)); ?>
						<legend><?php echo $fs_title; ?></legend>

						<?php foreach($blocks as $id=>$block) { ?>

							<?php if ($block['type'] == 'menu'){ ?>
								<div class="field">
									<label><?php echo $block['name']; ?></label>
									<?php echo html_select("prefs[{$layout_id}][blocks][{$id}][menu]", $menus, $block['menu']); ?>
								</div>
							<?php } ?>

							<?php if ($block['type'] == 'heading'){ ?>
								<div class="field">
									<label><?php echo $block['name']; ?></label>
									<?php echo html_input('text', "prefs[{$layout_id}][blocks][{$id}][text]", $block['text']); ?>
								</div>
							<?php } ?>

							<?php if ($block['type'] == 'image'){ ?>
								<div class="field">
									<label><?php echo $block['name']; ?></label>
									<?php echo html_input('text', "prefs[{$layout_id}][blocks][{$id}][src]", $block['src']); ?>
								</div>
							<?php } ?>

							<?php if ($block['type'] == 'text'){ ?>
								<div class="field">
									<label><?php echo $block['name']; ?></label>
									<?php echo html_textarea("prefs[{$layout_id}][blocks][{$id}][text]", $block['text']); ?>
								</div>
							<?php } ?>

						<?php } ?>

					</fieldset>

				<?php } ?>

                <?php if (!empty($opts['data_sources'])) { ?>
                    <?php foreach($opts['data_sources'] as $source_id => $ds) { ?>
                        <fieldset>
                            <legend><?php echo LANG_INPLAYER_PREF_DS_CONTENT; ?>: <?php echo isset($ds['name']) ? $ds['name'] : ''; ?></legend>

                            <div class="field ft_list">
                                <label><?php echo LANG_CONTENT_TYPE; ?></label>
                                <?php
                                    echo html_select("prefs[{$layout_id}][datasources][{$source_id}][ctypeId]", $ctypes, isset($ds['ctypeId']) ? $ds['ctypeId'] : '', array(
                                        'data-source-id' => $source_id,
                                        'class' => 'ds-ctype-list'
                                    ));
                                ?>
                            </div>

                            <?php foreach($ds['blocks'] as $id => $block) { ?>

                                <div class="field ft_list">
                                    <label>Поле: <?php echo $block['title']; ?></label>
                                    <select
                                        name="prefs[<?php echo $layout_id; ?>][datasources][<?php echo $source_id; ?>][blocks][<?php echo $id; ?>][<?php echo $block['saveToField']; ?>]"
                                        data-value="<?php echo $block['fieldName']; ?>"
                                        data-type="<?php echo $block['fieldType']; ?>"
                                        class="ds-<?php echo $source_id; ?>"></select>
                                    <?php if (isset($field_types[$block['fieldType']])){ ?>
                                        <div class="hint">
                                            <?php echo $field_types[$block['fieldType']]; ?>
                                        </div>
                                    <?php } ?>
                                </div>

                            <?php } ?>

                        </fieldset>
                    <?php } ?>
                <?php } ?>

            </div>
        <?php } ?>

    </div>

</fieldset>