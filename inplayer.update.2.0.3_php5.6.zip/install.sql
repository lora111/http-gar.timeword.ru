UPDATE `{#}controllers` SET version = '2.0.3' WHERE name = 'inplayer';
