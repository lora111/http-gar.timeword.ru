ExtJS 3 ACE Editor Component
============================

A component to wrap the ACE Editor for ExtJS 3.

Notes
=====

  * The `ace`, `cockpit` and `pilot` mappings are needed in `./package.json` because the ACE plugin manager resolves
    plugin IDs against the program boot package (typically this package).
